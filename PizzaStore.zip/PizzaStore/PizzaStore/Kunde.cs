﻿
namespace PizzaStore
{
    public class Kunde
    {
        #region Instance fields
        private string _name;
        private string _email;
        private string _address;

        #endregion

        #region Consstructor
        public Kunde (string name, string email, string address)
        {
            _name = name;
            _email = email;
            _address = address;
        }
        #endregion

        #region Properties
        public string Name
        {
            get { return _name; }
        }

        public string Email
        {
            get { return _email; }
        }

        public string Address
        {
            get { return _address; }
        }
        #endregion

        #region Methods
        public override string ToString()
        {
            return "Kundes navn er " + _name + " og har email: " + _email + " og addresse: " + _address;
        }
        #endregion
    }
}
