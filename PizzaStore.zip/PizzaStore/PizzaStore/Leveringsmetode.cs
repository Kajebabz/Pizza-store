﻿
namespace PizzaStore
{
    public class Leveringsmetode
    {
        #region Instance fields
        #endregion

        #region Consstructor
        #endregion

        #region Properties
        #endregion

        #region Methods
        #endregion
    }
}
