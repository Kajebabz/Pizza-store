﻿
namespace PizzaStore
{
    public class Ordre
    {
        #region Instance fields
        private int _orderNr;
        Pizza _pizzaItem;
        Kunde _nyKunde;

        #endregion

        #region Consstructor
        public Ordre(int orderNr, Pizza pizzaItem, Kunde nyKunde)
        {
            _orderNr = orderNr;
            _pizzaItem = pizzaItem;
            _nyKunde = nyKunde;
        }
        #endregion

        #region Properties
        public int OrderNr
        {
            get { return _orderNr; }
        }

        #endregion

        #region Methods
        private double CalculateTotalPrize(double price)
        {
            return (price) * 1.25 + 40;
        }

        public override string ToString()
        {
            return "Tak for din bestilling " + _nyKunde.Name + "! Du har bestilt " + _pizzaItem.Name + ", dit ordre nummer er: " + _orderNr + " og din totale pris er: " + CalculateTotalPrize(_pizzaItem.Price);
        }
        #endregion
    }
}
