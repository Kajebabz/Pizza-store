﻿
namespace PizzaStore
{
    public class Pizza
    {
        #region Instance fields
        private int _nr;
        private string _name;
        private string _toppings;
        private int _price;
        #endregion

        #region Consstructor
        public Pizza (int nr, string name, string toppings, int price)
        {
            _nr = nr;
            _name = name;
            _toppings = toppings;
            _price = price;
        }
        #endregion

        #region Properties

        public int Nr
        {
            get { return _nr; }
        }

        public string Name
        {
            get { return _name; }
        }

        public string Toppings
        {
            get { return _toppings; }   
        }

        public int Price
        {
            get { return _price; }
        }
        #endregion

        #region Methods
        public override string ToString()
        {
            return "Pizza nr. " + _nr + " " + _name + ", Indeholder: " + _toppings + ", og koster: " + _price + "kr";
        }
        #endregion 
    }
}
