﻿
namespace PizzaStore
{
    public class Pizzaria
    {
        #region Instance fields
        #endregion

        #region Consstructor
        #endregion

        #region Properties
        #endregion

        #region Methods
        #endregion
    }
}
