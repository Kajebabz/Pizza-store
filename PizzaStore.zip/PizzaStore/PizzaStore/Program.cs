﻿
using PizzaStore;

class program
{
    static void Main(String[] args)
    {
        Store store = new Store();
        store.Start();  
        //Kunde kunde1 = new Kunde("Peter", "hopla123@yahoo.com", "Rørmosen 12 4000 Roskilde");
        //Kunde kunde2 = new Kunde("Lars", "Momse54@jubii.dk", "Gartnervang 39, 4000 Roskilde");
        //Kunde kunde3 = new Kunde("Pernille", "Pernille92@hotmail.com", "Oldvejsparken 42 4000 Roskilde");


        //Pizza pizza1 = new Pizza(1, "Hawaii", "Tomat, ost, skinke, ananas", 59);
        //Pizza pizza2 = new Pizza(2, "Napoli", "Tomat, ost, kødsovs, løg", 65);
        //Pizza pizza3 = new Pizza(3, "Milano", "Tomat ost, skinke, pepperoni, kebab, bacon", 78);

        //Ordre ordre1 = new Ordre(1, pizza1, kunde1);
        //Ordre ordre2 = new Ordre(2, pizza2, kunde2);
        //Ordre ordre3 = new Ordre(3, pizza3, kunde3);


        //Console.WriteLine(kunde1);
        //Console.WriteLine(kunde2);
        //Console.WriteLine(kunde3);

        //Console.WriteLine();
        //Console.WriteLine();

        //Console.WriteLine(pizza1);
        //Console.WriteLine(pizza2);
        //Console.WriteLine(pizza3);

        //Console.WriteLine();
        //Console.WriteLine();

        //Console.WriteLine(ordre1);
        //Console.WriteLine(ordre2);
        //Console.WriteLine(ordre3);
    }
}




